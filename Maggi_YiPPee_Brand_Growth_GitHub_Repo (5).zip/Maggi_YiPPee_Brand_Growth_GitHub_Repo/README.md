# Indian Instant Noodles Market — Brand Growth & Competitor Benchmarking

**A comparative study of MAGGI and Sunfeast YiPPee! | MBA Marketing portfolio project**

## Project overview
This secondary-research project compares MAGGI and Sunfeast YiPPee! across brand positioning, product portfolios, selected retail prices, marketing mix and growth opportunities in India's instant noodles category.

## Business questions
- How do the two brands differentiate their consumer propositions?
- What can selected product and retail-price observations tell us about pack-level value?
- How do their product, price, place and promotion strategies compare?
- What practical growth opportunities can be proposed for each brand?

## Scope of analysis
- Category context and competitive landscape
- Brand background and positioning
- Segmentation, targeting and positioning (STP)
- Marketing mix (4Ps)
- Selected SKU and pack-size benchmarking
- Price per 100 g calculations where pack weights are sufficiently clear
- Product claims and communication cues
- SWOT and strategic recommendations
- Google Trends search-interest observations and regional patterns

## Deliverables
- `Maggi_YiPPee_Competitor_Benchmarking_Analysis.xlsx` — analysis workbook
- `Maggi_YiPPee_Brand_Growth_Competitor_Benchmarking_Report.docx` — research report
- `Maggi_YiPPee_Brand_Growth_Project_Deck.pptx` — presentation
- `Research_References/` — supporting research workbook and Google Trends exports used in the project

## Methodology
The project uses desk research and selected retailer listing observations. Product and price observations are time-stamped and should be treated as snapshots, not permanent market prices. Price per 100 g is calculated as:

`(Observed selling price ÷ pack weight in grams) × 100`

Google Trends values represent relative search interest, not absolute search volume, market share, sales or brand preference.

## Key evidence limitations
- This is secondary research; no new consumer survey or interviews were conducted for this report.
- Selected online listings do not measure total distribution, weighted availability, stock-outs or national average prices.
- Pack weights/listing details that were ambiguous are flagged and should not be treated as exact like-for-like comparisons.
- Nutrition values are transcribed from available listings; missing or unclear units are not treated as zero or used to rank healthfulness.
- Brand positioning and STP interpretations are analytical inferences from public communication and product range, not validated consumer perceptions.
- Search interest is not equivalent to purchase behaviour.
- Company statements about brand position are attributed to the company, not presented as independent market-share audits.

## Skills demonstrated
Brand strategy · Competitor benchmarking · STP · 4Ps · SWOT · Retail price analysis · Google Trends interpretation · Secondary research · Strategic recommendations

## Suggested next steps
Repeat price observations across retailers and cities; archive campaign creatives with dates; verify pack-level claims from official packaging; and conduct a properly sampled consumer study to test brand associations and purchase drivers.

## Author
MBA Marketing portfolio project.
