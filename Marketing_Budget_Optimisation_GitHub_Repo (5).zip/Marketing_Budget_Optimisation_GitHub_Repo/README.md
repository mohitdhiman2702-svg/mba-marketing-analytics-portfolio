# Marketing Budget Optimisation & ROI Simulator

**Portfolio project | MBA Marketing | Excel-based marketing analytics**

## Project overview
This project demonstrates how a marketing team can evaluate channel-level campaign performance and explore how a fixed marketing budget could be allocated across channels. It uses an illustrative **₹1 crore planning budget** and a clearly labelled synthetic campaign dataset.

> **Data disclosure:** Campaign-level spend, impressions, clicks, conversions and revenue in the simulator are synthetic/illustrative. They are not actual results from any company, brand, advertising platform or live campaign. Model outputs are scenario estimates, not forecasts or causal proof.

## Business question
How can a marketing team compare channel efficiency and create a disciplined, assumption-led budget allocation scenario?

## Channels covered
- Search advertising
- Social media
- Influencer marketing
- Traditional media

## Analysis and metrics
- Click-through rate (CTR)
- Cost per click (CPC)
- Conversion rate (CVR)
- Cost per acquisition/conversion (CPA)
- Return on ad spend (ROAS)
- Contribution-based ROI, with the return definition stated in the workbook
- Monthly and channel-level comparisons
- Budget allocation scenario and diminishing-return assumptions

## Deliverables
- `Marketing_Budget_Optimisation_ROI_Simulator.xlsx` — analysis workbook and simulator
- `Marketing_Budget_Optimisation_Project_Report.docx` — written report
- `Marketing_Budget_Optimisation_Project_Deck.pptx` — presentation

## Method
1. Structure campaign-level inputs by month and channel.
2. Calculate funnel and cost-efficiency KPIs.
3. Compare channels while checking denominator and attribution definitions.
4. Apply an illustrative budget-allocation model under stated assumptions.
5. Translate the scenario into recommendations for further testing and measurement.

## Interpretation cautions
- A high ROAS does not, by itself, establish incremental impact or profitability.
- Revenue attribution, gross margin, customer lifetime value, media overlap and lag effects should be validated before a real budget decision.
- The allocation is sensitive to the model's response and diminishing-return assumptions.
- Synthetic results must never be represented as actual campaign performance.

## Skills demonstrated
Marketing analytics · Budget planning · Excel modelling · KPI design · Performance marketing · Scenario analysis · Business recommendations

## Suggested next steps
Replace illustrative inputs with an authorised real campaign export; validate attribution windows and margins; add incremental lift or holdout-test results; then rerun the allocation scenario.

## Author
MBA Marketing portfolio project.
